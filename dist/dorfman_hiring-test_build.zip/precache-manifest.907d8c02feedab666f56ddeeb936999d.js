self.__precacheManifest = [
  {
    "revision": "04845bf4fb4667249a36",
    "url": "./static/css/main.6cc5a8c2.chunk.css"
  },
  {
    "revision": "04845bf4fb4667249a36",
    "url": "./static/js/main.04845bf4.chunk.js"
  },
  {
    "revision": "890541514c684abac97d",
    "url": "./static/js/1.89054151.chunk.js"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "b2a3f1a19618e4797728680315f28580",
    "url": "./index.html"
  }
];